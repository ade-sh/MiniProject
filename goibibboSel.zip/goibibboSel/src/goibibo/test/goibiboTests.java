package goibibo.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class goibiboTests {
	WebDriver driver;
	Document docPath,docVal;
	File src;
	File valSrc;
	SAXReader saxReader;
	FileInputStream fis,fis2;
	public goibiboTests(WebDriver driver) {
		this.driver = driver;
		src = new File("./src/reposit/TestORpath.xml");
		valSrc=new File("./src/reposit/TestORvalues.xml");
		//test data in xml format
		
		try {
			fis = new FileInputStream(src);
			saxReader = new SAXReader();
			docPath = saxReader.read(fis);
			fis2=new FileInputStream(valSrc);
			docVal=saxReader.read(fis2);
		} catch (FileNotFoundException | DocumentException e) {
			e.printStackTrace();
		}
	}

	public void clickThis(String xPath) {
		WebDriverWait wait = new WebDriverWait(driver, 30);//Explicit wait
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xPath)));
		driver.findElement(By.xpath(xPath)).click();
	}

	public void typeThis(String inputStr, String xPath) {
		driver.findElement(By.xpath(xPath)).sendKeys(inputStr);

	}
	public String docXpath(String Xword){
		String xpathCr=docPath.selectSingleNode("//ibibo/home/".concat(Xword)).getText();
		return xpathCr;
	}
	
    public String docXval(String Xword){
    	String xpathVal="//ibibo/home/".concat(Xword);
		return docVal.selectSingleNode(xpathVal).getText();
	}
	public void selectClass(String name, String xPath1) {
		Select drpClass=new Select(driver.findElement(By.xpath(xPath1)));
		drpClass.selectByValue(name);
	}
	
}
