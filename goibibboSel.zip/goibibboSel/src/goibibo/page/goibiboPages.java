package goibibo.page;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.concurrent.TimeUnit;

import goibibo.test.goibiboTests;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class goibiboPages  {
	WebDriver driver;
	goibiboTests goTests;
	goibiboPages goPages;
	
	
	

	@BeforeClass
	public void initTestEle() {
		System.setProperty("webdriver.chrome.driver","D:\\Adesh\\Advanced Selenium Libs\\chrome\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.goibibo.com/");
		System.out.println("Starting Test");
		goTests = PageFactory.initElements(driver, goibiboTests.class);
		goPages = new goibiboPages();
		goPages.sleep(1000);
		
	}

	
	@Test(priority = 1)
	public void setinputvalue() {
		//gbt.wait(arg0, arg1);
		//goTests.clickThis("bsRoundTrip");
		System.out.println("Starting Test 2");
		goTests.clickThis(goTests.docXpath("roundTrip"));
		goTests.typeThis(goTests.docXval("sourceCityValue"), goTests.docXpath("sourceCity"));
		goPages.sleep(2000);
		goTests.typeThis(goTests.docXval("destCityVlue"),goTests.docXpath("destCity"));
		goPages.sleep(1000);
	}
	@Test(priority = 2)
	public void testForDate() {
		System.out.println("Starting Test 3");
		goTests.clickThis(goTests.docXpath("day1"));
		goPages.sleep(3000);
		goTests.clickThis(goTests.docXval("dayVal"));
		goTests.clickThis(goTests.docXpath("day2"));
		goTests.clickThis(goTests.docXval("dayVal2"));
		goPages.sleep(1000);
	}

	@AfterClass
	public void endindTask() {
		driver.quit();
		goTests = null;
	}

	@Test(priority = 3)
	public void testForSelectClss() {
		System.out.println("Starting Test 4 ");
		goTests.selectClass(goTests.docXval("classVal"), goTests.docXpath("class"));
		goTests.clickThis(goTests.docXpath("goBtn"));
			}

	@Test(priority = 4)
	public void testForSetBtn() {
		goTests.clickThis(goTests.docXpath("Book/bookBtn"));
		goPages.sleep(9000);
	}
	
	public void sleep(int timeForWait) {
		try {
			Thread.sleep(timeForWait);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}