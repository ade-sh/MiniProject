package Ibibo.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class ibiboPage {
    
	WebDriver driver;
	Document document;
	FileInputStream fis1;
	SAXReader saxReader1;
	
	public void open(){
	File src = new File("./Input/NewFile.xml");
    try {
		fis1 = new FileInputStream(src);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    saxReader1 = new SAXReader();
	try {
		document = saxReader1.read(fis1);
	} catch (DocumentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}
	
	public void click(String Xpath)
	{
		driver.findElement(By.xpath(Xpath)).click();
	}
	
	public void typeThis(String Xpath,String value)
	{
		driver.findElement(By.xpath(Xpath)).sendKeys(value);
	}
	
	public void selectItem(String Xpath,String name)
	{
		Select drp=new Select(driver.findElement(By.xpath(Xpath)));
		drp.selectByVisibleText(name);
	}
	public String doc(String Val){
		return document.selectSingleNode("//goibibo/From/".concat(Val)).getText();
	}

	public ibiboPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
}
	

