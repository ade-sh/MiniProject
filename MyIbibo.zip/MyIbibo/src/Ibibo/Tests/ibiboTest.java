package Ibibo.Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Ibibo.pages.ibiboPage;

public class ibiboTest {
	
	WebDriver driver;
	ibiboPage pge;
	ibiboTest tst;
	
	@BeforeTest
	public void Open(){
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.goibibo.com/");
		pge=PageFactory.initElements(driver,ibiboPage.class);
		tst=new ibiboTest();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
   @Test
   public void fun(){
	   pge.click(pge.doc("round"));
   }
}
